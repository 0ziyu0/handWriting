package com.codingapi.tm.netty.service;

/**
 * Created by lorne on 2017/6/30.
 */
public interface NettyServerService {

    void start();

    void close();


}
