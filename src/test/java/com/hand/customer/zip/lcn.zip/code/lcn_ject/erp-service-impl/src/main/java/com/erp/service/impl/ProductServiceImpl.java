package com.erp.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.codingapi.tx.annotation.TxTransaction;
import com.erp.entity.Product;
import com.erp.mapper.ProductMapper;
import com.erp.service.IProductService;

@Service
public class ProductServiceImpl /*extends BaseServiceImpl<Product, Long>*/ implements IProductService {

	@Resource
	private ProductMapper productMapper;

	public List<Product> selectProductByName(String name) {
		
		List<Product> list = new ArrayList<>();
		Product p = productMapper.selectByPrimaryKey(1L);
		list.add(p);
		
		return list;
	}

	@Override
	public Integer insert(Product product, Integer i) {
		
		product.setName("erp_product_has_transaction");
		product.setPrice(1000L);
		int result = productMapper.insert(product);
		
		if(i != null) {
			i = 1 / i;
		}
		
		return result;
	}

	@Override
	public Integer insert2(Product product, Integer i) {
		
		product.setName("erp_product_not_transaction");
		product.setPrice(1000L);
		int result = productMapper.insert(product);
		
		if(i != null) {
			i = 1 / i;
		}
		
		return result;
	}
	
	/*@Resource(name = "productMapper")
	@Override
	public void setBaseMapper(BaseMapper<Product, Long> baseMapper) {
		this.baseMapper = baseMapper;
	}*/

	/*@Override
	public List<Product> selectProductByName(String name) {
		
		Product product = new Product();
		product.setName(name);
		return this.selectByModel(product);
		
	}*/
	

}
