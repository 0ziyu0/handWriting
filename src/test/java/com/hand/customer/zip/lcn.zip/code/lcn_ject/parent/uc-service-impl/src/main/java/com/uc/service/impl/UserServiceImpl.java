package com.uc.service.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingapi.tx.annotation.TxTransaction;
import com.erp.entity.Product;
import com.uc.entity.User;
import com.uc.feign.ErpServiceFeign;
import com.uc.mapper.UserMapper;
import com.uc.service.IUserService;

@Service
public class UserServiceImpl implements IUserService {

	@Resource
	private UserMapper userMapper;
	
	@Autowired
	private ErpServiceFeign erpServiceFeign;
	
	@Override
	@TxTransaction(isStart = true)
	public void saveUser(User user, Integer i, Integer j) {
		
		// 先保存商品，后在保存用户
		Product p = new Product();
		Integer result = erpServiceFeign.insert(p, i);
		System.out.println("erp feign result " + result);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int insert = userMapper.insert(user);
		if(j != null) {
			int x = 1 / j;
		}
		System.out.println(insert);
		
	}

	@Override
	public void saveUser2(User user, Integer i, Integer j) {
		
		// 先保存商品，后在保存用户
		Product p = new Product();
		Integer result = erpServiceFeign.insert2(p, i);
		System.out.println("erp feign result " + result);
		int insert = userMapper.insert(user);
		if(j != null) {
			int x = 1 / j;
		}
		System.out.println(insert);
		
	}

}
