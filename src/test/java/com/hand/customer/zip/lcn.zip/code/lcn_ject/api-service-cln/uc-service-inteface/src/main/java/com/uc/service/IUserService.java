package com.uc.service;

import com.uc.entity.User;

public interface IUserService {

	public void saveUser(User user, Integer i, Integer j);
	
	public void saveUser2(User user, Integer i, Integer j);
	
}
