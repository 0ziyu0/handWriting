package com.erp.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.erp.entity.Product;

public interface IProductService {
	
	@RequestMapping(value = "/selectProductByName", method= RequestMethod.GET)
	public List<Product> selectProductByName(String name);
	
	@RequestMapping(value = "/insert", method= RequestMethod.POST)
	public Integer insert(@RequestBody Product product, @RequestParam("i")Integer i);
	
	
	@RequestMapping(value = "/insert2", method= RequestMethod.POST)
	public Integer insert2(@RequestBody Product product, @RequestParam("i")Integer i);
	
}
