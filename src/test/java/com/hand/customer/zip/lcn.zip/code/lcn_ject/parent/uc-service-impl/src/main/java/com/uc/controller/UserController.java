
package com.uc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.uc.entity.User;
import com.uc.service.IUserService;

@RestController
public class UserController {

	@Autowired
	private IUserService userService;
	
	@RequestMapping("/saveUser")
	public String saveUser(Integer i, Integer j) {
		
		User user = new User();
		user.setName("lisi");
		user.setAge(10);
		userService.saveUser(user, i, j);
		
		return "ok";
		
	}
	
	@RequestMapping("/saveUser2")
	public String saveUser2(Integer i, Integer j) {
		
		User user = new User();
		user.setName("lisi");
		user.setAge(10);
		userService.saveUser2(user, i, j);
		
		return "ok";
		
	}
	
}
