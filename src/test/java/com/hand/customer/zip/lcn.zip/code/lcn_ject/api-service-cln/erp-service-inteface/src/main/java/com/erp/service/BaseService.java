package com.erp.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

//import com.common.util.PageData;

public interface BaseService<T, PK extends Serializable> {

	//public PageData selectPage(PageData pageData);
	
	T insert(T model);
	
	int delete(PK modelPK);
	
	T load(T model);
	
	T update(T model);
	
	T selectById(PK modelPK);
	
	long selectCount(T model);
	
	boolean isExist(T model);
	
	List<Map<String, Object>> selectToList(T model);

    List<T> selectByModel(T model);
	
}
