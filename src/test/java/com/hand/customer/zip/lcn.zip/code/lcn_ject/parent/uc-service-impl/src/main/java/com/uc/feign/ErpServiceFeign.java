package com.uc.feign;

import org.springframework.cloud.openfeign.FeignClient;

import com.erp.service.IProductService;

@FeignClient("erp")
public interface ErpServiceFeign extends IProductService {
	
}
