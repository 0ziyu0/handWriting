package com.erp;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@MapperScan(basePackages = { "com.erp.mapper" })
@EnableEurekaClient
@EnableFeignClients
@ImportResource("classpath:transaction.xml")
public class ErpApp {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(ErpApp.class, args);
	}

	
}
