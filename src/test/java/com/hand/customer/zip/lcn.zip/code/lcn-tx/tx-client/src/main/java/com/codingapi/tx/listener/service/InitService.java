package com.codingapi.tx.listener.service;

/**
 * Created by yuliang on 2017/7/11.
 */
public interface InitService {

    void start();
}
