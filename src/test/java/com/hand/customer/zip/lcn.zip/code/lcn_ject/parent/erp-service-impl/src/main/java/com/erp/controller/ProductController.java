package com.erp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erp.entity.Product;
import com.erp.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	private IProductService productService;
	
	@RequestMapping("/getProduct")
	public List<Product> getProduct() {
		
		return productService.selectProductByName("");
	}
	
	@RequestMapping("/saveProduct")
	public Integer saveProduct(Integer i) {
		
		Product p = new Product();
		p.setName("王五");
		p.setPrice(11L);
		
		Integer result = productService.insert(p, i);
		
		return result;
	}
	
	@RequestMapping("/insert")
	public Integer insert(@RequestBody Product product, Integer i) {
		
		Integer result = productService.insert(product, i);
		
		return result;
	}
}
