package com.codingapi.tm.listener.service;

/**
 * Created by lorne on 2017/7/4.
 */
public interface InitService {

    void start();


    void close();
}
