package com.cloud.lock;

import java.util.UUID;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class RedisLock {

	private JedisPool jedisPool;
	
	public RedisLock (JedisPool jedisPool) {
		this.jedisPool = jedisPool;
	}
	
	/**
	 * 
	 * @param lockKey
	 * @param waitTimeout 锁的等待时间
	 * @param timeOut lockKey的超时时间  以毫秒为单位
	 * @return
	 */
	public String getLock(String lockKey, Long waitTimeout, Long timeOut) {
		
		Jedis jedisConnection = null;
		String resultIdentifier = null;
		
		try {
			jedisConnection = jedisPool.getResource();
			String identifier = UUID.randomUUID().toString().replaceAll("-", "");
			Integer expireLock = (int)(timeOut / 1000);
			Long waitEndTime = System.currentTimeMillis() + waitTimeout;
			// 这里采用while来做重试机制
			while(System.currentTimeMillis() < waitEndTime) {
				// setnx 成功返回1，失败返回0  注意 此方法 先给设上值 然后在设置有效期 有轻微的延迟
				if(jedisConnection.setnx(lockKey, identifier) == 1) {
					jedisConnection.expire(lockKey, expireLock);
					resultIdentifier = identifier;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(jedisConnection != null) {
				jedisConnection.close();
			}
		}
		
		return resultIdentifier;
	}
	
	/**
	 * 释放锁
	 * @param lockKey
	 * @param identifier
	 * @return
	 */
	public Boolean unLock(String lockKey, String identifier) {
		
		Jedis jedisConnection = null;
		Boolean resultFlag = false;
		try {
			jedisConnection = jedisPool.getResource();
			// 判读是同一个上锁对象，则删除
			if(identifier.equals(jedisConnection.get(lockKey))) {
				jedisConnection.del(lockKey);
				resultFlag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(jedisConnection != null) {
				jedisConnection.close();
			}
		}
		
		return resultFlag;
	}
}
