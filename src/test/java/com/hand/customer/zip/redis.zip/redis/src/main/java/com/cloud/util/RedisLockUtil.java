package com.cloud.util;

import org.springframework.util.StringUtils;

import com.cloud.lock.RedisLock;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class RedisLockUtil {

	private static JedisPool jedisPool = null;
	
	static {
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		// 设置最大连接数
		jedisPoolConfig.setMaxTotal(200);
		// 设置最大空闲数
		jedisPoolConfig.setMaxIdle(5);
		// 最大等待数
		jedisPoolConfig.setMaxWaitMillis(1000 * 100);
		//在获取连接的时候检查有效性, 默认false
		jedisPoolConfig.setTestOnBorrow(true);
		jedisPool = new JedisPool(jedisPoolConfig, "127.0.0.1", 6379, 3000);
	}
	
	RedisLock redisLock = new RedisLock(jedisPool);
	
	public void test() {
		
		String key = "ziyu";
		String identifier = redisLock.getLock(key, 8000L, 8000L);
		if(StringUtils.isEmpty(identifier)) {
			System.out.println(Thread.currentThread().getName() + " getLock timeout... ");
			return;
		}
		System.out.println(" getLock success identifier is " + identifier);
		try {
			// 处理业务逻辑
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// 释放锁
		Boolean releaseLock = redisLock.unLock(key, identifier);
		if(releaseLock) {
			System.out.println(" release lock success... ");
		}
	}
}
