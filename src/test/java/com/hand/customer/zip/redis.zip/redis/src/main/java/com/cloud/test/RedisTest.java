package com.cloud.test;

import com.cloud.util.RedisLockUtil;

class Resource extends Thread {

	private RedisLockUtil redisLockUtil;
	
	public Resource(RedisLockUtil redisLockUtil) {
		this.redisLockUtil = redisLockUtil;
	}
	
	@Override
	public void run() {
		redisLockUtil.test();
	}
}

public class RedisTest {
	
	public static void main(String[] args) {
		
		RedisLockUtil redisLockUtil = new RedisLockUtil();
		
		for(int i = 0; i < 50; i++) {
			Resource re = new Resource(redisLockUtil);
			re.start();
		}
	}
	
}
