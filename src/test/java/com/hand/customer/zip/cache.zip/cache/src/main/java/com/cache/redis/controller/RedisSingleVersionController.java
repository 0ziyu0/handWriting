package com.cache.redis.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cache.redis.utils.RedisUtil;


@RestController
public class RedisSingleVersionController {

	@Autowired
	private RedisUtil redisUtil;
	
	@RequestMapping("/setStr")
	public String setStr(String key, String value) {
		
		String result = "success";
		
		try {
			redisUtil.set(key, value, null);
		} catch (Exception e) {
			e.printStackTrace();
			result = "error";
		}
		
		return result;
	}
	
	@RequestMapping("/set")
	public String set(String key) {
		
		String result = "success";
		
		try {
			Set<String> value = new HashSet<String>();
			value.add("t1");
			value.add("t2");
			value.add("t3");
			redisUtil.set(key, value, null);
		} catch (Exception e) {
			e.printStackTrace();
			result = "error";
		}
		
		return result;
	}
}
