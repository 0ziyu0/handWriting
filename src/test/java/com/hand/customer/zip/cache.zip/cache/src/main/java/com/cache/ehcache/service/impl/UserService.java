package com.cache.ehcache.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cache.ehcache.entity.User;
import com.cache.ehcache.mapper.UserMapper;

@Service
public class UserService {

	@Autowired
	private UserMapper userMapper;
	
	public List<User> getUser(Long id) {
		
		List<User> userList = null;
		if(id != null) {
			userList = userMapper.getUser(id);
		}
		
		return userList;
	}
	
}
