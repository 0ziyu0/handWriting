package com.cache.ehcache;

import java.util.Map;

import org.springframework.stereotype.Component;

import net.sf.ehcache.util.concurrent.ConcurrentHashMap;

@Component
public class EhcacheMap<K, V> {

	private Map<K, V> echcache = new ConcurrentHashMap<>();
	
	public void put(K key, V value) {
		echcache.put(key, value);
	}
	
	public V get(K key) {
		return echcache.get(key);
	}
	
	public void remove(K key) {
		echcache.remove(key);
	}
}
