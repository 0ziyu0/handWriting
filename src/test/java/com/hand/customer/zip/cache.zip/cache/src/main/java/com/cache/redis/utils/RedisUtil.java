package com.cache.redis.utils;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

@Component
public class RedisUtil {

	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	
	public void set(String key, Object obj, Long timeout) {
		if(obj instanceof String) {
			setString(key, obj);
		} else if(obj instanceof Set) {
			setSet(key, obj);
		}
		// 设置有效期
		if(timeout != null) {
			stringRedisTemplate.expire(key, timeout, TimeUnit.SECONDS);
		}
	}
	
	private void setSet(String key, Object obj) {
		
		@SuppressWarnings("unchecked")
		Set<String> value = (Set<String>) obj;
		for (String str : value) {
			stringRedisTemplate.opsForSet().add(key, str);
		}
	}

	private void setString(String key, Object obj) {
		
		String value = (String)obj;
		
		stringRedisTemplate.opsForValue().set(key, value);;
	}
	
}
