package com.cache.ehcache.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cache.ehcache.EhcacheMap;
import com.cache.ehcache.entity.User;
import com.cache.ehcache.service.impl.UserService;

@RestController
public class EhcacheSingleVersionController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CacheManager cacheManager;
	
	@Autowired
	private EhcacheMap<String, String> ehcacheMap;
	
	@RequestMapping("/clear")
	public String clear() {
		
		cacheManager.getCache("userCache").clear();
		
		return "success";
	}
	
	@RequestMapping("/getUser")
	public List<User> getUser(Long id) {
		
		return userService.getUser(id);
	}
	
	@RequestMapping("/save")
	public String save(String name, Long id) {
		
		ehcacheMap.put(id.toString(), name);
		
		return "success";
	}
}
