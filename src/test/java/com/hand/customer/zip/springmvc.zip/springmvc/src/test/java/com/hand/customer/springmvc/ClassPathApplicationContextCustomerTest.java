package com.hand.customer.springmvc;

import com.hand.customer.springmvc.service.CustomerApplicationContextService;

public class ClassPathApplicationContextCustomerTest {

	public static void main(String[] args) {
		
		DispatcherServletCustomer app = new DispatcherServletCustomer();
		CustomerApplicationContextService customerService = (CustomerApplicationContextService) app.getInstanceBean("customerApplicationContextServiceImpl");
		customerService.testCustomerApplicationContextTest();
	}
	
}
