package com.hand.customer.springmvc.dao;

public interface CustomerApplicationContextDao {

	public void testCustomerApplicationContextTest();
	
}
