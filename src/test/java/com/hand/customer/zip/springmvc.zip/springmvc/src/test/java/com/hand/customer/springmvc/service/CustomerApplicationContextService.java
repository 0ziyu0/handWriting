package com.hand.customer.springmvc.service;

public interface CustomerApplicationContextService {

	public void testCustomerApplicationContextTest();
	
}
