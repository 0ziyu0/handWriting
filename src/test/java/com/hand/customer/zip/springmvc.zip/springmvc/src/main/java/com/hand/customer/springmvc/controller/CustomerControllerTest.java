package com.hand.customer.springmvc.controller;

import com.hand.customer.springmvc.annotation.CustomerController;
import com.hand.customer.springmvc.annotation.CustomerRequestMapping;

@CustomerController
@CustomerRequestMapping("/test")
public class CustomerControllerTest {
	
	@CustomerRequestMapping("/index")
	public String index() {
		
		System.out.println("=====");
		
		return "index";
	}
	
}
