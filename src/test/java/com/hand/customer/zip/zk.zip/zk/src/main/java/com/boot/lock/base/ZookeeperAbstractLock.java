package com.boot.lock.base;

import java.util.concurrent.CountDownLatch;

import org.I0Itec.zkclient.ZkClient;

import com.boot.lock.inteface.Lock;

public abstract class ZookeeperAbstractLock implements Lock {

	private static final String CONNECTION_ADDRESS = "127.0.0.1:2181";
	
	protected ZkClient zkClient = new ZkClient(CONNECTION_ADDRESS);
	
	protected static final String LOCK_PATH = "/lock";
	
	protected CountDownLatch countDownLatch = null;
	
	@Override
	public void getLock() {
		if(tryLock()) {
			System.out.println("获取到锁资源...");
		} else {
			waitLock();
			//再次获取
			getLock();
		}
		
	}

	abstract void waitLock();

	abstract boolean tryLock();

	@Override
	public void unLock() {
		if(zkClient != null) {
			zkClient.close();
			System.out.println("释放锁资源...");
		}

	}

}
