package com.boot.lock.base;

import java.util.concurrent.CountDownLatch;

import org.I0Itec.zkclient.IZkDataListener;

public class ZookeeperLock extends ZookeeperAbstractLock {

	@Override
	void waitLock() {
		
		IZkDataListener listener = new IZkDataListener() {
			// 当临时文件被删除时调用
			@Override
			public void handleDataDeleted(String dataPath) throws Exception {
				if(countDownLatch != null) {
					countDownLatch.countDown();
				}
			}
			
			@Override
			public void handleDataChange(String dataPath, Object data) throws Exception {
			
			}
		};
		// 监听节点
		zkClient.subscribeDataChanges(LOCK_PATH, listener);
		if(zkClient.exists(LOCK_PATH)) {
			countDownLatch = new CountDownLatch(1);
			try {
				countDownLatch.await();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		zkClient.unsubscribeDataChanges(LOCK_PATH, listener);
	}

	@Override
	boolean tryLock() {
		
		boolean createFlag = true;
		try {
			zkClient.createEphemeral(LOCK_PATH);
		} catch (Exception e) {
			//e.printStackTrace();
			createFlag = false;
		} 
		
		return createFlag;
	}

}
