package com.boot.controller;

public class IndexController {

}
