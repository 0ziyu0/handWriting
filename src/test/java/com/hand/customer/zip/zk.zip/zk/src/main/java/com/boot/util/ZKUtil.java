package com.boot.util;

import java.util.concurrent.CountDownLatch;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;

public class ZKUtil {

	private static final String addres = "127.0.0.1:2181";

	private static final Integer sessionOuttime = 2000;

	private static final CountDownLatch countDownLatch = new CountDownLatch(1);
	
	public static void main(String[] args) throws Exception {
		
		// 注意这里需要携带/
		String path = "/ziyu_001";
		String value = "ziyu_value";
		ZooKeeper zk = new ZooKeeper(addres, sessionOuttime, new Watcher() {
			public void process(WatchedEvent event) {
				// 获取当前连接的状态(包含连接、关闭连接、过期、验证失败)
				KeeperState state = event.getState();
				// 获取当前节点的事件类型(包含对节点增加、修改、删除等)
				EventType type = event.getType();
				if(KeeperState.SyncConnected == state) {
					if(EventType.None == type) {
						countDownLatch.countDown();
						System.out.println("zk连接...");
					}
				}
			}
		});
		// 由于上面zk是单独启动一个线程去连接的，在这里使用CountDownLatch在阻塞程序，让其在连接成功后在执行后续逻辑
		countDownLatch.await();
		// PERSISTENT 临时节点(程序关闭即删除练级) EPHEMERAL 持久节点  SEQUENTIAL 是否序列化
		String result = zk.create(path, value.getBytes(), Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
		System.out.println("result: " + result);
		Thread.sleep(8000);
		if(zk != null) {
			zk.close();
		}
	}

}
