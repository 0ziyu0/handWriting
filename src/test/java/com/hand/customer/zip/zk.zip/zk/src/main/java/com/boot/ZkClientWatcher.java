package com.boot;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;

/**
 * 这里封装对zk的操作
 * @author liuwenjun
 *
 */
public class ZkClientWatcher implements Watcher {
	
	// 若是集群则用逗号分隔
	private static final String CONNECTION_ADDRESS = "127.0.0.1:2181";
	private static final Integer SESSION_TIMEOUT = 2000;
	private static final CountDownLatch countDownLatch = new CountDownLatch(1);
	
	private ZooKeeper zk;
	
	@Override
	public void process(WatchedEvent event) {
		
		KeeperState keeperState = event.getState();
		EventType eventType = event.getType();
		// 当前zk路径
		String path = event.getPath();
		System.out.println("====== this is path : " + path + "========");
		if(KeeperState.SyncConnected == keeperState) {
			if(EventType.None == eventType) {
				countDownLatch.countDown();
				System.out.println("zk start success...");
			} else if(EventType.NodeCreated == eventType) {
				System.out.println("zk node creat...");
			} else if(EventType.NodeDeleted == eventType) {
				System.out.println("zk node deleted...");
			} else if(EventType.NodeDataChanged == eventType) {
				System.out.println("zk node changed...");
			}
		}
	}
	
	/**
	 * 创建zk连接
	 * @param address
	 * @param timeOut
	 * @return
	 */
	public Boolean createConnection(String address, Integer timeOut) {
		
		Boolean connectionFlag = false;
		try {
			zk = new ZooKeeper(address, timeOut, this);
			connectionFlag = true;
		} catch (IOException e) {
			e.printStackTrace();
			if(zk != null) {
				try {
					zk.close();
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}
		}
		
		return connectionFlag;
	}
	
	/**
	 * 创建节点
	 * @param path
	 * @param value
	 * @return
	 */
	public Boolean createPath(String path, String value) {
		
		Boolean createFlag = false;
		try {
			this.pathExist(path, true);
			this.zk.create(path, value.getBytes(), Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
			createFlag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return createFlag;
	}
	
	/**
	 * 更新节点
	 * @param path
	 * @param value
	 * @return
	 */
	public Boolean updateNode(String path, String value) {
		
		Boolean updateFlag = false;
		try {
			this.pathExist(path, true);
			this.zk.setData(path, value.getBytes(), -1);
			updateFlag = true;
		} catch (KeeperException | InterruptedException e) {
			e.printStackTrace();
		}
		
		return updateFlag;
	}
	
	/**
	 * 获取节点
	 * @param path
	 * @return
	 */
	public String getNode(String path) {
		
		String resultDate = null;
		try {
			byte[] data = this.zk.getData(path, this, pathExist(path, true));
			if(data != null) {
				resultDate = new String(data);
			}
		} catch (KeeperException | InterruptedException e) {
			e.printStackTrace();
		}
		
		return resultDate;
	}
	
	public Stat pathExist(String path, boolean needWatch) {
		
		Stat exists = null;
		try {
			exists = this.zk.exists(path, needWatch);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return exists;
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		String node = "/ziyu_002";
		String nodeValue = "value_002";
		String nodeUpdate = "value_002_update";
		
		ZkClientWatcher zkWatcher = new ZkClientWatcher();
		zkWatcher.createConnection(CONNECTION_ADDRESS, SESSION_TIMEOUT);
		zkWatcher.createPath(node, nodeValue);
		
		System.out.println(zkWatcher.getNode(node));
		Thread.sleep(5000);
		
		zkWatcher.updateNode(node, nodeUpdate);
		
		System.out.println(zkWatcher.getNode(node));
		
		Thread.sleep(7000);
	}
}
